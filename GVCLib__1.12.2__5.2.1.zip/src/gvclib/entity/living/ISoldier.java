package gvclib.entity.living;

public interface ISoldier
{
	//public boolean medic = false;
	
}